# Star Wars: Blaster Battle
A browser-based side-scrolling shooting game where you play as Luke Skywalker. Blast stormtroopers and save the galaxy!

## How to Play
- Arrow Up/Down to move
- Spacebar to shoot

Open `index.html` in any modern browser to play.
