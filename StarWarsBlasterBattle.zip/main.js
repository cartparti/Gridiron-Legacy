const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const lukeImg = new Image();
lukeImg.src = 'assets/images/luke.png';
const stormtrooperImg = new Image();
stormtrooperImg.src = 'assets/images/stormtrooper.png';
const blasterSound = new Audio('assets/sounds/blaster.wav');
const explosionSound = new Audio('assets/sounds/explosion.wav');

let player = { x: 50, y: 250, width: 64, height: 64, health: 100, bullets: [] };
let enemies = [];
let keys = {};
let score = 0;

function drawPlayer() {
  ctx.drawImage(lukeImg, player.x, player.y, player.width, player.height);
}

function drawEnemies() {
  enemies.forEach(enemy => {
    ctx.drawImage(stormtrooperImg, enemy.x, enemy.y, enemy.width, enemy.height);
    enemy.x -= enemy.speed;
  });
}

function drawBullets() {
  player.bullets.forEach(bullet => {
    ctx.fillStyle = 'red';
    ctx.fillRect(bullet.x, bullet.y, 10, 4);
    bullet.x += 10;
  });
}

function spawnEnemy() {
  enemies.push({
    x: canvas.width,
    y: Math.random() * (canvas.height - 64),
    width: 64,
    height: 64,
    speed: 2 + Math.random() * 2
  });
}

function checkCollisions() {
  enemies.forEach((enemy, ei) => {
    player.bullets.forEach((bullet, bi) => {
      if (
        bullet.x < enemy.x + enemy.width &&
        bullet.x + 10 > enemy.x &&
        bullet.y < enemy.y + enemy.height &&
        bullet.y + 4 > enemy.y
      ) {
        explosionSound.play();
        enemies.splice(ei, 1);
        player.bullets.splice(bi, 1);
        score += 10;
      }
    });

    if (
      enemy.x < player.x + player.width &&
      enemy.x + enemy.width > player.x &&
      enemy.y < player.y + player.height &&
      enemy.y + enemy.height > player.y
    ) {
      player.health -= 10;
      enemies.splice(ei, 1);
    }
  });
}

function drawHUD() {
  ctx.fillStyle = 'white';
  ctx.fillText(`Score: ${score}`, 10, 20);
  ctx.fillText(`Health: ${player.health}`, 10, 40);
}

function update() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  drawPlayer();
  drawBullets();
  drawEnemies();
  drawHUD();
  checkCollisions();

  if (keys['ArrowUp'] && player.y > 0) player.y -= 5;
  if (keys['ArrowDown'] && player.y < canvas.height - player.height) player.y += 5;

  if (player.health <= 0) {
    ctx.fillStyle = "red";
    ctx.font = "48px Arial";
    ctx.fillText("Game Over!", canvas.width / 2 - 100, canvas.height / 2);
    return;
  }

  requestAnimationFrame(update);
}

document.addEventListener('keydown', e => {
  keys[e.key] = true;
  if (e.key === ' ') {
    player.bullets.push({ x: player.x + player.width, y: player.y + 25 });
    blasterSound.play();
  }
});
document.addEventListener('keyup', e => {
  keys[e.key] = false;
});

setInterval(spawnEnemy, 1000);
update();
